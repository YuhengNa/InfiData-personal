"""Robot Video Segmentor - Configuration management."""

from dataclasses import dataclass, field
from typing import List, Optional, Union
from pathlib import Path
import json
import os
import yaml
from pydantic import BaseModel, Field, field_validator


class DatasetConfig(BaseModel):
    """Dataset configuration."""
    root: str = Field(..., description="Path to data root directory")
    subset: str = Field(..., description="Subset/directory name")
    format: str = Field(default="folder", description="Input format: folder or infidata")
    video_key: str = Field(default="cam_high", description="InfiData camera key to use")

    @field_validator("format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        allowed = ["folder", "infidata"]
        if v not in allowed:
            raise ValueError(f"format must be one of {allowed}, got {v}")
        return v


class RunConfig(BaseModel):
    """Run/output configuration."""
    base_dir: str = Field(default="./runs", description="Base directory for outputs")
    run_id: str = Field(default="default", description="Run identifier")


class ServerConfig(BaseModel):
    """Server configuration."""
    host: str = Field(default="0.0.0.0", description="Server bind host")
    port: int = Field(default=8099, description="Server port")
    max_queue: int = Field(default=32, description="Maximum job queue size")
    inflight_timeout_sec: float = Field(default=300.0, description="Timeout for in-flight jobs")
    max_retries_per_job: int = Field(default=5, description="Maximum retries per job")
    auto_exit_after_all_done: bool = Field(default=False, description="Auto exit when all done")


class Qwen3VLConfig(BaseModel):
    """Qwen3VL-specific configuration."""
    model_path: str = Field(
        default="Qwen/Qwen3-VL-32B-Instruct",
        description="Model path or HuggingFace model name"
    )
    device_map: str = Field(default="balanced", description="Device map strategy")


class RemoteAPIConfig(BaseModel):
    """Remote API backend configuration."""
    api_url: str = Field(default="http://127.0.0.1:8080/infer", description="Remote API URL")
    api_key: str = Field(default="", description="API key for remote API")
    timeout_sec: float = Field(default=60.0, description="Request timeout in seconds")
    headers: dict = Field(default_factory=dict, description="Extra headers for remote API")


class WorkerConfig(BaseModel):
    """Worker configuration."""
    server_url: str = Field(default="http://127.0.0.1:8099", description="Server URL")
    backend: str = Field(default="dummy", description="VLM backend type")
    qwen3vl: Qwen3VLConfig = Field(default_factory=Qwen3VLConfig)
    remote_api: RemoteAPIConfig = Field(default_factory=RemoteAPIConfig)

    @field_validator("backend")
    @classmethod
    def validate_backend(cls, v: str) -> str:
        allowed = ["dummy", "qwen3vl", "remote_api"]
        if v not in allowed:
            raise ValueError(f"backend must be one of {allowed}, got {v}")
        return v


class WindowingConfig(BaseModel):
    """Video windowing configuration."""
    window_sec: float = Field(default=16.0, description="Window duration in seconds")
    step_sec: float = Field(default=8.0, description="Step size in seconds")
    frames_per_window: int = Field(default=16, description="Frames per window")
    target_width: int = Field(default=720, description="Target frame width")
    target_height: int = Field(default=480, description="Target frame height")
    png_compression: int = Field(default=0, description="PNG compression level (0-9)")


class SegmentationConfig(BaseModel):
    """Subtask segmentation behavior."""
    mode: str = Field(
        default="coarse",
        description="Segmentation mode: coarse/object_switch or fine/action_phase",
    )

    @field_validator("mode")
    @classmethod
    def validate_mode(cls, v: str) -> str:
        aliases = {
            "coarse": "coarse",
            "object_switch": "coarse",
            "fine": "fine",
            "action_phase": "fine",
        }
        key = v.lower()
        if key not in aliases:
            allowed = sorted(aliases)
            raise ValueError(f"mode must be one of {allowed}, got {v}")
        return aliases[key]


class AnnotationConfig(BaseModel):
    """Annotation heads to run for each video window."""
    targets: List[str] = Field(
        default_factory=lambda: ["subtask"],
        description="Annotation targets: subtask, memory, or both",
    )

    @field_validator("targets", mode="before")
    @classmethod
    def normalize_targets(cls, v):
        if isinstance(v, str):
            return [v]
        return v

    @field_validator("targets")
    @classmethod
    def validate_targets(cls, v: List[str]) -> List[str]:
        allowed = {"subtask", "memory"}
        targets = []
        for item in v:
            key = str(item).lower()
            if key not in allowed:
                raise ValueError(f"annotation target must be one of {sorted(allowed)}, got {item}")
            if key not in targets:
                targets.append(key)
        if not targets:
            raise ValueError("annotation.targets must not be empty")
        return targets


class InfiDataConfig(BaseModel):
    """Controls writing annotation results back into an InfiData dataset."""
    write_back: bool = Field(
        default=False,
        description="Write generated annotations into <dataset>/meta JSONL files",
    )
    update_parquet_subtasks: bool = Field(
        default=False,
        description="Update each episode parquet subtask column from generated subtask segments",
    )
    update_parquet_memory_summaries: bool = Field(
        default=False,
        description="Update each episode parquet memory summary column from generated memory segments",
    )
    parquet_memory_column: str = Field(
        default="summary",
        description="Column name to store per-row memory summaries in episode parquet files",
    )


class MemoryConfig(BaseModel):
    """Memory annotation behavior."""
    use_subtask_context: bool = Field(
        default=True,
        description="Include existing subtask segments in memory prompts when available",
    )
    align_to_subtasks: bool = Field(
        default=True,
        description="Use existing subtask boundaries as memory segment boundaries when available",
    )


class VisualizationConfig(BaseModel):
    """Render annotated videos for quality inspection."""
    enabled: bool = Field(default=False, description="Render a visualization video after each episode")
    output_dir: str = Field(
        default="",
        description="Optional output directory. Defaults to <run_dir>/visualizations",
    )
    panel_height: int = Field(default=180, description="Bottom annotation panel height in pixels")


class ProgressConfig(BaseModel):
    """Progress tracking configuration."""
    total_override: int = Field(default=0, description="Override total count (0=auto)")


class LoggingConfig(BaseModel):
    """Logging configuration."""
    level: str = Field(default="INFO", description="Log level")

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: str) -> str:
        allowed = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        v_upper = v.upper()
        if v_upper not in allowed:
            raise ValueError(f"level must be one of {allowed}, got {v}")
        return v_upper


class Config(BaseModel):
    """Main application configuration."""
    datasets: List[DatasetConfig] = Field(default_factory=list)
    run: RunConfig = Field(default_factory=RunConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)
    worker: WorkerConfig = Field(default_factory=WorkerConfig)
    windowing: WindowingConfig = Field(default_factory=WindowingConfig)
    segmentation: SegmentationConfig = Field(default_factory=SegmentationConfig)
    annotation: AnnotationConfig = Field(default_factory=AnnotationConfig)
    infidata: InfiDataConfig = Field(default_factory=InfiDataConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    visualization: VisualizationConfig = Field(default_factory=VisualizationConfig)
    progress: ProgressConfig = Field(default_factory=ProgressConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    @classmethod
    def from_yaml(cls, path: Union[str, Path]) -> "Config":
        """Load configuration from YAML file."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        
        return cls(**data)
    
    @classmethod
    def from_env(cls) -> "Config":
        """Load configuration from environment variables."""
        config = cls()
        
        # Override with env vars if present
        if "DATASETS" in os.environ:
            config.datasets = _parse_datasets_env(os.environ["DATASETS"])
        if "RUN_BASE" in os.environ:
            config.run.base_dir = os.environ["RUN_BASE"]
        if "RUN_ID" in os.environ:
            config.run.run_id = os.environ["RUN_ID"]
        if "PORT" in os.environ:
            config.server.port = int(os.environ["PORT"])
        if "SERVER_URL" in os.environ:
            config.worker.server_url = os.environ["SERVER_URL"]
        if "MODEL_PATH" in os.environ:
            config.worker.qwen3vl.model_path = os.environ["MODEL_PATH"]
        if "BACKEND" in os.environ:
            config.worker.backend = os.environ["BACKEND"]
        if "REMOTE_API_URL" in os.environ:
            config.worker.remote_api.api_url = os.environ["REMOTE_API_URL"]
        if "REMOTE_API_KEY" in os.environ:
            config.worker.remote_api.api_key = os.environ["REMOTE_API_KEY"]
        if "REMOTE_API_TIMEOUT" in os.environ:
            config.worker.remote_api.timeout_sec = float(os.environ["REMOTE_API_TIMEOUT"])
        if "REMOTE_API_HEADERS" in os.environ:
            headers_raw = os.environ["REMOTE_API_HEADERS"]
            headers = json.loads(headers_raw)
            if not isinstance(headers, dict):
                raise ValueError("REMOTE_API_HEADERS must be a JSON object")
            config.worker.remote_api.headers = headers
        if "SEGMENTATION_MODE" in os.environ:
            config.segmentation.mode = SegmentationConfig(mode=os.environ["SEGMENTATION_MODE"]).mode
        
        return config
    
    @classmethod
    def load(cls, path: Optional[Union[str, Path]] = None) -> "Config":
        """Load configuration with priority: file > env > defaults."""
        if path:
            return cls.from_yaml(path)
        
        # Try to find config.yaml in current directory
        default_path = Path("config.yaml")
        if default_path.exists():
            return cls.from_yaml(default_path)
        
        # Fall back to environment variables
        return cls.from_env()


def _parse_datasets_env(spec: str) -> List[DatasetConfig]:
    """Parse DATASETS environment variable."""
    configs = []
    parts = [p.strip() for p in spec.split(";") if p.strip()]
    for p in parts:
        if ":" in p:
            root, subset = p.split(":", 1)
            configs.append(DatasetConfig(root=root.strip(), subset=subset.strip()))
        else:
            data_dir = Path(p.rstrip("/"))
            root = str(data_dir.parent)
            subset = data_dir.name
            configs.append(DatasetConfig(root=root, subset=subset))
    return configs
